import os

class Config:
    SECRET_KEY = 'supersecretkey123'
    SQLALCHEMY_DATABASE_URI = 'mysql+pymysql://root@localhost/secdoc'
    SQLALCHEMY_TRACK_MODIFICATIONS = False
    SESSION_TYPE = 'filesystem'

    OKTA_CLIENT_ID = '0oaotwn94oeMEB1wh5d7'
    OKTA_CLIENT_SECRET = '73E6CHi-JMOmhNBEuQIMTN-D8iRC2mldrqs6xgG9_Gxk5uiGBNTrE8JCkPMZK6yt'
    OKTA_DOMAIN = 'https://dev-64656133.okta.com'
    
    
    # GitHub
    GITHUB_CLIENT_ID = os.getenv("Ov23lipy1R5cTbtMMzCN")
    GITHUB_CLIENT_SECRET = os.getenv("352cd8ff1c5c5a928487ad3b59ce82780b68585a")



    GOOGLE_CLIENT_ID = os.getenv("526006122178-8qdq7t2rpln6huj758tqomaq444rbu9m.apps.googleusercontent.com")
    GOOGLE_CLIENT_SECRET = os.getenv("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")
